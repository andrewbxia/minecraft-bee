# Goguardian-bypasser
An attempt to bypass goguardian via google services

### What is goguardian???
A google chrome plugin that teachers use to block websites on chrombooks (that plugin usually blocks something that is not supposed to be blocked and teachers are not good at helping us unblock those websites).

### How does this code work?
A google api allows me to download the source code of any website (including the blocked ones)
https://developers.google.com/apps-script/reference/url-fetch/url-fetch-app

### Where should the code go? 
Not on your computer, but https://script.google.com. Create a new project with your account.
I can only connect to the internet via my chromebook or I will use other bypassing methods.

### Known issues:
Cannot log in (facebook or ins or snapchat)
Cannot watch youtube (it always tells me something is wrong)
A lot of other issues!!
Mostly caused by Access-Control-Allow-Origin (any ideas on how to fix it?)



  
   
  <br />
  <br />

Since there is no computer science class in my high school, I learned coding by myself online (there are a lot of resorces online). If there is anywhere I should improve, please tell me!

**NOTE: Please do not make any money with my code**


I wrote these codes a few months ago. Now I have already found a lot of different ways to bypass this giant URL searcher. My current website can even bypass youtube video. However, I don't want to update this repo any more since it is fun to discover and utilize bugs by yourself. If you wish to start discovering, just remember: this is nothing but a chrome extension. 

Useful websites: <br />
https://gist.github.com/paulirish/78d6c1406c901be02c2d <br />
chrome://policy/ -> ExtensionInstallForcelist -> Show Value -> find goguardian
