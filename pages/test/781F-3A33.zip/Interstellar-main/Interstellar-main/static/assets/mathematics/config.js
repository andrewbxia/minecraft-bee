self.__uv$config = {
  prefix: "/a/",
  bare: "/ca/",
  encodeUrl: Ultraviolet.codec.xor.encode,
  decodeUrl: Ultraviolet.codec.xor.decode,
  handler: "/assets/mathematics/handler.js?v=9-30-2024",
  bundle: "/assets/mathematics/bundle.js?v=9-30-2024",
  config: "/assets/mathematics/config.js?v=9-30-2024",
  sw: "/assets/mathematics/sw.js?v=9-30-2024",
};
