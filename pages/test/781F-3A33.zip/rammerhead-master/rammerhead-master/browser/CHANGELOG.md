# v1.0.0

- Initial Release

# v1.0.1-1.0.8

- Minor Bugfixes

# v1.0.9

- Fix with the prefix not adding a / at the end
