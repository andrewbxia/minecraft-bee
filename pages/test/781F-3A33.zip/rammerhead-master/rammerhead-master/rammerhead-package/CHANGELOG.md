# v1.3.6

- Bumps deps

# v1.3.5

- Bumps @rubynetwork/rh
  - Fixes issue due to https://

# v1.3.4

- Bump @rubynetwork/rh
  - Fixes random crashes

# 1.3.3

- Depend on set version of @rubynetwork/rh

# 1.3.2

- Make options configurable
