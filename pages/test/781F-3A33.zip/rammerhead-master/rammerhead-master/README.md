<div align="center">
         
<img src="https://socialify.git.ci/ruby-network/rammerhead/image?description=1&font=Inter&forks=1&issues=1&language=1&name=1&owner=1&pattern=Circuit%20Board&pulls=1&stargazers=1&theme=Dark" alt="rammerhead" width="640" height="320" />

<img alt="commit a week" src="https://img.shields.io/github/commit-activity/w/ruby-network/rammerhead?style=for-the-badge"></img>

</div>

<div align="center">
    <h2>Get Started</h2>
    <p>To see specific instructions, visit the project you need</p>
</div>

---
- [Rammerhead](./rammerhead/)
    - The actual fork of Rammerhead
    - [npm](https://www.npmjs.com/package/@rubynetwork/rh)

<br />

- [Rammerhead Package](./rammerhead-package/)
    - An easy way to use Rammerhead on the server
    - [npm](https://www.npmjs.com/package/@rubynetwork/rammerhead)

<br />

- [Browser](./browser/)
    - An easy way to use Rammerhead on the client
    - [npm](https://www.npmjs.com/package/@rubynetwork/rammerhead-browser)

---
##### All Projects in this Monorepo are licensed under the [MIT License](./LICENSE) ***Unless otherwise specified***
